<?php
include "db.php";
$res=mysqli_query($conn,"SELECT * FROM news WHERE status=0");
while($row=mysqli_fetch_assoc($res)){
echo "<h3>".$row['title']."</h3>";
echo $row['details']."<br>";
echo "<a href='news_edit.php?id=".$row['id']."'>Edit</a> ";
echo "<a href='news_delete.php?id=".$row['id']."'>Delete</a><hr>";
}
?>
