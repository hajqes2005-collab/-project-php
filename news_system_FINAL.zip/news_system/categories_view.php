<?php
include "db.php";
$res=mysqli_query($conn,"SELECT * FROM categories");
while($row=mysqli_fetch_assoc($res)){
echo $row['name']."<br>";
}
?>
