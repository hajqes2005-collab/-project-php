<?php
include "db.php";
session_start();

if(isset($_POST['login'])){
$email=$_POST['email'];
$pass=$_POST['password'];

$res=mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");
$row=mysqli_fetch_assoc($res);

if($row && password_verify($pass,$row['password'])){
$_SESSION['user']=$row['id'];
header("Location: dashboard.php");
}else{
echo "Wrong data";
}
}
?>
<form method="post">
<input name="email"><br>
<input name="password" type="password"><br>
<button name="login">Login</button>
</form>
