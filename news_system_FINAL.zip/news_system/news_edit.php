<?php
include "db.php";
$id=$_GET['id'];
$res=mysqli_query($conn,"SELECT * FROM news WHERE id=$id");
$row=mysqli_fetch_assoc($res);

if(isset($_POST['update'])){
$title=$_POST['title'];
$details=$_POST['details'];
mysqli_query($conn,"UPDATE news SET title='$title',details='$details' WHERE id=$id");
header("Location: news_view.php");
}
?>
<form method="post">
<input name="title" value="<?php echo $row['title'];?>"><br>
<textarea name="details"><?php echo $row['details'];?></textarea><br>
<button name="update">Update</button>
</form>
