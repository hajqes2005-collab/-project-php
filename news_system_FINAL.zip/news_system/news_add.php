<?php
include "db.php";
session_start();

$resCat=mysqli_query($conn,"SELECT * FROM categories");

if(isset($_POST['submit'])){
$title=$_POST['title'];
$cat=$_POST['category'];
$details=$_POST['details'];
$user=$_SESSION['user'];

$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'],"uploads/".$image);

mysqli_query($conn,"INSERT INTO news(title,category_id,details,image,user_id,status)
VALUES('$title','$cat','$details','$image','$user',0)");

echo "Added";
}
?>
<form method="post" enctype="multipart/form-data">
<input name="title"><br>
<select name="category">
<?php while($c=mysqli_fetch_assoc($resCat)){ ?>
<option value="<?php echo $c['id'];?>"><?php echo $c['name'];?></option>
<?php } ?>
</select><br>
<textarea name="details"></textarea><br>
<input type="file" name="image"><br>
<button name="submit">Add</button>
</form>
