<?php
include "db.php";
$res=mysqli_query($conn,"SELECT * FROM news WHERE status=1");
while($row=mysqli_fetch_assoc($res)){
echo "<h3>".$row['title']."</h3><hr>";
}
?>
