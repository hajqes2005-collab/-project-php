<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "news_system";

$conn = mysqli_connect($host,$user,$pass,$db);
if(!$conn){
    die("DB Connection Failed");
}
?>
