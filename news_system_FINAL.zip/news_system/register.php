<?php
include "db.php";
if(isset($_POST['submit'])){
$name=$_POST['name'];
$email=$_POST['email'];
$pass=password_hash($_POST['password'],PASSWORD_DEFAULT);

mysqli_query($conn,"INSERT INTO users(name,email,password) VALUES('$name','$email','$pass')");
echo "Registered";
}
?>
<form method="post">
<input name="name" placeholder="Name"><br>
<input name="email" placeholder="Email"><br>
<input name="password" type="password" placeholder="Password"><br>
<button name="submit">Register</button>
</form>
