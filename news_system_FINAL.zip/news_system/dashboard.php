<?php
include "db.php";
session_start();
if(!isset($_SESSION['user'])) header("Location: login.php");
echo "<h1>Dashboard</h1>";
echo "<a href='categories_add.php'>Add Category</a><br>";
echo "<a href='categories_view.php'>View Categories</a><br>";
echo "<a href='news_add.php'>Add News</a><br>";
echo "<a href='news_view.php'>View News</a><br>";
echo "<a href='news_deleted.php'>Deleted News</a><br>";
echo "<a href='logout.php'>Logout</a>";
?>
