<?php
include "db.php";
$id=$_GET['id'];
mysqli_query($conn,"UPDATE news SET status=1 WHERE id=$id");
header("Location: news_view.php");
?>
