<?php
include "db.php";
if(isset($_POST['submit'])){
$name=$_POST['name'];
mysqli_query($conn,"INSERT INTO categories(name) VALUES('$name')");
echo "Added";
}
?>
<form method="post">
<input name="name">
<button name="submit">Add</button>
</form>
